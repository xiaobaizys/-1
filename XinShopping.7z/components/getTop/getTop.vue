<template>
	<view>
		<view class="fixed-br" v-if="showTop" @click="toTop">
			<view id='top'>
				<image src="../../static/images/top.png" mode=""></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "getTop",
		props: {
			scrollTop: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				showTop: false
			};
		},
		watch: {
			scrollTop: {
				handler(newVal) {
					if (newVal >= 700) {
						this.showTop = true
					} else {
						this.showTop = false
					}
				},
				immediate: true
			}
		},
		methods:{
			toTop() {
				this.$emit('toTop')
			},
		}
	}
</script>

<style lang="scss" scoped>
	.fixed-br {
		position: fixed;
		z-index: 997;
		bottom: 1.9rem;
		right: 0.38rem;

		#top {
			display: block;
			width: 0.77rem;
			height: 0.77rem;
			margin: 0.1rem auto 0;

			image {
				width: 100%;
				height: 100%;
			}
		}
	}
</style>