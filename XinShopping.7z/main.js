import App from './App'
import $config from 'common/js/config.js'
import $request from 'common/js/request.js'
import store from '@/store'
import 'common/js/flexible.js'
import showModal from 'common/js/showModal.js'

//在main.js中加入以下代码
// uni.addInterceptor('request', {
// 	success(args) {
// 		let isLogin = uni.getStorageSync('isLogin') //isLogin是你调用登录接口成功后保存的一个状态，我在这里调用成功后设置成了isLogin="yes"
// 		if (args.statusCode == 401 && isLogin == 'yes') {
// 			showModal()
// 			//这句代码很重要，是为了防止401后再继续调用接口
// 			uni.setStorageSync('isLogin', 'no')
// 		}
// 	},
// 	fail(err) {

// 	}
// })


// #ifndef VUE3
import Vue from 'vue'
import './uni.promisify.adaptor'
import uView from "uview-ui";
Vue.use(uView);
Vue.config.productionTip = false
Vue.prototype.$config = $config
Vue.prototype.$request = $request
Vue.prototype.$store = store
App.mpType = 'app'
const app = new Vue({
	...App,
	store
})

app.$mount()
// #endif

// #ifdef VUE3
import {
	createSSRApp
} from 'vue'
export function createApp() {
	const app = createSSRApp(App)
	return {
		app
	}
}
// #endif