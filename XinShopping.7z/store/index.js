import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

const store = new Vuex.Store({
	state: {
		localData: {
			province_id: 2,
			city_id: 36,
			district_id: 377,
			area_id: 377017,
			name: '',
			data: {
				province: '',
				city: '',
				district: '',
				area: '',
			},
			addressInfo: "北京市 东城区"
		},
		idList: [],
	},
	mutations: {
		getPositionData(state, data) {
			if (data.addrs && data.addrs.length !== 0) {
				state.localData.name = data.name
				let str = ''
				data.addrs.forEach(item => {
					if (item.region_type == 1) {
						str += `${item.name}\u0020`
						state.localData.province_id = item.id
						state.localData.data.province = item.name
					} else if (item.region_type == 3) {
						str += `${item.name}`
						state.localData.district_id = item.id
						state.localData.data.district = item.name
					} else if (item.region_type == 2) {
						state.localData.city_id = item.id
						state.localData.data.city = item.name
					} else if (item.region_type == 4) {
						state.localData.area_id = item.id
						state.localData.data.area = item.name
					}
				})
				state.localData.addressInfo = str
			} else {
				state.localData.province_id = data.province.id
				state.localData.city_id = data.city.id
				state.localData.district_id = data.district.id
				state.localData.area_id = data.area.id
				state.localData.data.province = data.province.name
				state.localData.data.city = data.city.name
				state.localData.data.district = data.district.name
				state.localData.data.area = data.area.name
				let str = data.city.name + '\u0020' + data.district.name
				state.localData.addressInfo = str
			}
		},

		SET_ID_LIST(state, list) {
			state.idList = list
		},
	}

})
export default store