<script>
	export default {
		options: {
			styleIsolation: 'shared'
		},
		onLaunch() {
			let USER_TOKEN = uni.getStorageSync('USER_TOKEN')
			if (!USER_TOKEN) {
				uni.setStorageSync('isLogin', 'no')
			} else {
				uni.setStorageSync('isLogin', 'yes')
			}
			let list = uni.getStorageSync('searchInfo')
			if (list.length == 0) {
				uni.setStorageSync('searchInfo', []);
			}
		},
	};
</script>
<style lang="scss">
	@import "uview-ui/index.scss";

	view {
		font-family: Helvetica Neue, Tahoma, Arial, PingFangSC-Regular, Hiragino Sans GB, Microsoft Yahei, sans-serif;
	}

	.addition-tips {
		position: absolute;
		top: 0;
		right: 0.25rem;
		height: 0.27rem;
		line-height: .27rem;
		margin-top: -0.7em;
		color: #ff5934;
		background: #ffe4d1;
		font-size: .19rem;

		&:before {
			position: absolute;
			content: "";
			left: -0.12rem;
			top: 0;
			width: 0.13rem;
			height: 0.27rem;
			background: url(static/images/ser_left.png) no-repeat;
			background-size: 100% 100%;
		}

		&::after {
			position: absolute;
			content: "";
			right: -0.25rem;
			top: 0;
			width: 0.25rem;
			height: 0.4rem;
			background: url(static/images/ser_right.png) no-repeat;
			background-size: 100% 100%;
		}
	}

	.serve-option-act {
		.addition-tips {
			background: #ff7d00;
			color: #fff;

			&:before {
				background: url(static/images/ser_left_act.png) no-repeat;
				background-size: 100% 100%;
			}

			&::after {
				background: url(static/images/ser_right_act.png) no-repeat;
				background-size: 100% 100%;
			}
		}
	}

	.viewport-container {
		background: rgb(255, 255, 255);
		width: 100%;
		height: 100%;

		.MuiCollapse-container {
			.pageLayout {
				padding: 0 .54rem .54rem;

				.heade {
					.BrowserTitle {
						justify-content: space-between;
						padding: .3rem 0;
						align-items: center;
						color: rgba(0, 0, 0, .5);
						display: flex;
						font-size: .27rem;
						font-weight: 400;
						line-height: .36rem;

						._-src-components-NewNavbar-BrowserTitle-language {
							align-items: center;
							display: flex;
							justify-content: flex-start;
							overflow: hidden;
						}

						._-src-components-NewNavbar-BrowserTitle-flex_box {
							align-items: center;
							display: flex;
						}
					}

					.BrowserTitle-title {
						font-weight: 600;
						overflow: hidden;
						text-overflow: ellipsis;
						padding: .23rem 0 .3rem;
						text-align: center;
						align-items: center;
						color: rgba(0, 0, 0, .8);
						display: flex;
						font-size: .38rem;
						justify-content: center;
						line-height: .52rem;
					}
				}
			}

			._-src-components-Banner-root {
				margin: 0 auto;
				padding-bottom: 1rem;
				padding-top: .077rem;
				flex-direction: column;

				image {
					text-align: center;
					width: .92rem;
					height: .92rem;
				}

				._-src-components-Banner-slogan {
					transform: none;
					transition: transform 225ms cubic-bezier(0, 0, 0.2, 1) 0ms;
					color: rgba(0, 0, 0, .6);
					font-size: .33rem;
					font-weight: 400;
					line-height: .44rem;
					margin-top: .36rem;
					text-align: center;
				}
			}
		}

	}

	.mfbs-main-content {
		view {
			line-height: 1.15;
		}

		.app-content {
			.app-content-header {
				padding-bottom: .1rem;

				uni-swiper,
				.swiper-item,
				/deep/.uni-swiper-wrapper {
					height: 4.4rem;

					image {
						width: 100%;
						height: 4.4rem;
					}
				}
			}
		}
	}

	.maxW,
	/deep/.u-transition {
		max-width: 720px !important;
		min-width: 350px !important;
		margin: 0 auto;
	}

	.maxF {
		left: 50% !important;
		transform: translateX(-50%);
	}

	.header-comp {
		position: relative;
		max-width: 720px !important;
		min-width: 350px !important;
		margin: 0 auto;
		z-index: 999;

		.header {
			position: fixed;
			top: 0;
			width: 7.2rem;
			z-index: 99;
		}

		.header-bar {
			position: relative;
			background: #fafafa;
		}
	}

	.fixed-br {
		position: fixed;
		z-index: 997;
		bottom: 1.9rem;
		right: 0.38rem;

		#top {
			display: block;
			width: 0.77rem;
			height: 0.77rem;
			margin: 0.1rem auto 0;

			image {
				width: 100%;
				height: 100%;
			}
		}
	}

	.buybtn {
		line-height: 1.15;
		margin: 0 auto;
		width: 2rem;
		background: #ea625b;
		border-radius: 0.05rem;
		text-align: center;
		color: #fff;
		font-size: .24rem;
		padding: 0.16rem 0;
		font-weight: 700;
	}

	.header {
		max-width: 720px !important;
		min-width: 350px !important;
		margin: 0 auto;
		height: 0.9rem;
		background: transparent;
		top: 0;
		left: 0;
		right: 0;
		z-index: 99;
		line-height: 1.15;

		view {
			line-height: 1.15;
		}

	}


	.load {
		height: 100vh;
		width: 100%;
	}

	.sup {
		font-size: 10px;
		vertical-align: text-top;
	}

	.sub {
		font-size: 10px;
		vertical-align: text-bottom;
	}

	/deep/.uni-tabbar__icon {
		display: block;
		width: 0.4rem !important;
		height: 0.4rem !important;
		max-width: 30px;
		max-height: 30px;
	}

	/deep/.uni-tabbar__label {
		font-size: .2rem !important;
	}
</style>
<style>
	@import './common/css/common.css';
	@import './common/css/uni.css';
	@import './common/css/animate.css';

	.u-navbar--fixed,
	.uni-tabbar {
		max-width: 720px !important;
		min-width: 350px !important;
		margin: 0 auto;
	}

	.uni-tabbar {
		height: 0.9rem;
	}
</style>