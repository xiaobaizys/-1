<template>
	<view class="container el-flex">
		<image src="https://s1.mi.com/m/ghd/2016/x0718m03/static/img/404.3ec06ef.jpg" mode="heightFix"></image>
		<view class="err">
			抱歉，页面找不到了...
		</view>
		<view class="goto" @click="toHome">
			<text>商城首页 mi.com</text>
		</view>
	</view>
</template>

<script>
	export default {
		methods: {
			toHome() {
				uni.switchTab({
					url: '/pages/home/home'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		width: 100%;
		height: 6rem;
		position: absolute;
		margin: -3rem 0 0 -50%;
		top: 50%;
		left: 50%;
		flex-direction: column;

		image {
			display: block;
			height: 4rem;
			margin: 0 auto 0.5rem;
		}

		.err {
			font-size: .45rem;
			line-height: .68rem;
		}

		.goto {
			text {
				font-size: .3rem;
				line-height: .68rem;
				color: #0b72a4;
			}
		}
	}
</style>
