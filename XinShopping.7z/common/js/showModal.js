const showModal = function() {
	uni.showModal({
		title: "温馨提示",
		content: '登录已过期,重新登录',
		cancelText: "取消",
		confirmText: "确定",
		confirmColor: "#815EC9",
		showCancel: false,
		success: (res) => {
			if (res.confirm) {
				uni.redirectTo({
					url: '/pages/login-view/login-view' //跳到登录页
				})
			} else if (res.cancel) {}
		}
	});
}
export default showModal