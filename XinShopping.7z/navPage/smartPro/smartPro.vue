<template>
	<view class="mfbs-main-content" style="background-color: rgb(219, 233, 236);">
		<toTop :scrollTop='scrollTop' @toTop='toTop'></toTop>
		<template v-if="Object.keys(dataInfo).length==0||result_list.length==0">
			<view class="load">
				<u-loading-page :loading="true"></u-loading-page>
			</view>
		</template>
		<template v-else>
			<mfbsHead :backColor='backColor' :title='title' :isShow='isShow' :img_url='img_url'></mfbsHead>
			<view class="app-content">
				<view class="app-content-header">
					<swiper :indicator-dots="true" :autoplay="true" :interval="3500" :duration="1000">
						<swiper-item v-for="(item,index) in swiperList" :key="index">
							<view class="swiper-item">
								<image :src="item.pic_url" mode=""></image>
							</view>
						</swiper-item>
					</swiper>
				</view>
				<view class="app-content-view">
					<block v-for="(item,index) in dataList" :key="index">
						<rowDetail :dataInfo='item'></rowDetail>
					</block>

				</view>
			</view>

		</template>
	</view>
</template>

<script>
	import mfbsHead from '../../components/mfbs-header/mfbs-header.vue'
	import toTop from '../../components/getTop/getTop.vue'
	import rowDetail from '../../components/row-detail/row-detail.vue'
	let query_1 = {
		"query_list": [{
				"resolver": "mi-actinian-accept-award",
				"sign": "d4cf75ec8234ea0825fa3fe44a3ea41e",
				"parameter": "{\"actId\":\"644745d5be07770001121546\"}",
				"variable": {}
			},
			{
				"resolver": "mishop-grating",
				"sign": "fc3f219c6b12110c4d848d4b0256e24d",
				"parameter": "{\"plan_ids\":[],\"manual_sort\":\"artificial_weight\",\"selectImg\":\"img800s\",\"labels_filter\":\"\",\"need_all\":false,\"limit\":11}",
				"variable": {}
			},
			{
				"resolver": "mishop-grating",
				"sign": "04123fabe73c123e9c58b93ba76c3edc",
				"parameter": "{\"plan_ids\":[1009373],\"manual_sort\":\"artificial_weight\",\"selectImg\":\"img800s\",\"labels_filter\":\"\",\"need_all\":false,\"limit\":30,\"column_number\":3}",
				"variable": {}
			}
		]
	}
	let query_2 = {
		"query_list": [{
				"resolver": "mishop-grating",
				"sign": "539a726199bace540487e7776ef933b5",
				"parameter": "{\"plan_ids\":[1008196],\"manual_sort\":\"artificial_weight\",\"selectImg\":\"img800s\",\"labels_filter\":\"\",\"need_all\":false,\"limit\":18,\"column_number\":3}",
				"variable": {}
			},
			{
				"resolver": "mishop-grating",
				"sign": "250612fdce07f7ac2408928747924a41",
				"parameter": "{\"plan_ids\":[1008197],\"manual_sort\":\"artificial_weight\",\"selectImg\":\"img800s\",\"labels_filter\":\"\",\"need_all\":false,\"limit\":18,\"column_number\":3}",
				"variable": {}
			},
			{
				"resolver": "mishop-grating",
				"sign": "ea27805e856c642d4c105082c33464f0",
				"parameter": "{\"plan_ids\":[1008198],\"manual_sort\":\"artificial_weight\",\"selectImg\":\"img800s\",\"labels_filter\":\"\",\"need_all\":false,\"limit\":18,\"column_number\":3}",
				"variable": {}
			},
			{
				"resolver": "mishop-grating",
				"sign": "465103bb7dd4aebef7f63c60c0d7dcfd",
				"parameter": "{\"plan_ids\":[1008199],\"manual_sort\":\"artificial_weight\",\"selectImg\":\"img800s\",\"labels_filter\":\"\",\"need_all\":false,\"limit\":18,\"column_number\":3}",
				"variable": {}
			},
			{
				"resolver": "mishop-grating",
				"sign": "55c1fa195fa7553fa06e5e934c9f338e",
				"parameter": "{\"plan_ids\":[1008200],\"manual_sort\":\"artificial_weight\",\"selectImg\":\"img800s\",\"labels_filter\":\"\",\"need_all\":false,\"limit\":18,\"column_number\":3}",
				"variable": {}
			},
			{
				"resolver": "mishop-grating",
				"sign": "2c46758e8f2cbf59bc89dee9e4bdb1a0",
				"parameter": "{\"plan_ids\":[1008201],\"manual_sort\":\"artificial_weight\",\"selectImg\":\"img800s\",\"labels_filter\":\"\",\"need_all\":false,\"limit\":18,\"column_number\":3}",
				"variable": {}
			}
		]
	}
	export default {
		components: {
			toTop,
			rowDetail,
			mfbsHead
		},
		data() {
			return {
				img_url: 'left',
				isShow: false,
				scrollTop: 0,
				firstList: [],
				floorList: [],
				backColor: 'transparent',
				dataInfo: {},
				swiperList: [],
				title: '',
				fusion_custom_image: [],
				result_list: []
			};
		},
		onPageScroll(res) {
			this.scrollTop = res.scrollTop
			if (res.scrollTop >= 100) {
				this.isShow = true
				this.img_url = 'left_b'
				this.backColor = 'rgb(244, 244, 244)'
			} else {
				this.backColor = 'transparent'
				this.img_url = 'left'
				this.isShow = false
			}
		},
		computed: {
			dataList() {
				if (this.result_list.length == 0) return
				let list = []
				this.fusion_custom_image.forEach((item, index) => {
					if (index == 0) {
						list.push({
							first: item,
							second: this.firstList
						})
					} else {
						if (!this.result_list[index - 1]) return;
						list.push({
							first: item,
							second: this.result_list[index - 1].list
						})
					}
				})
				return list;
			}
		},
		methods: {
			toTop() {
				uni.pageScrollTo({
					duration: 0,
					scrollTop: 0,
				})
			},
			getVenueBatchList(type) {
				let queryData
				if (type == 1) {
					queryData = query_1
				} else if (type == 2) {
					queryData = query_2
				}
				this.$request.get('/getVenueBatchList', {
					page_id: '11760',
					queryData: queryData,
					sign: '5ce232871184f3781d5dccf7165f5638'
				}).then((res) => {
					if (type == 1) {
						let list = res.data.data.result_list
						list.forEach(item => {
							if (item) {
								this.firstList = item.list
							}
						})
					} else {
						this.result_list = res.data.data.result_list
					}
				}).catch(e => {
					console.log('错误了:', e)
				})
			},
			getVenuePageList() {
				this.$request.get('/getVenuePageList', {
					page_id: '11760',
					sign: '5ce232871184f3781d5dccf7165f5638'
				}).then((res) => {
					this.floorList = res.data.data.floors
					this.dataInfo = res.data.data.setting
					this.title = res.data.data.title
					this.floorList.forEach(item => {
						if (item.module_key == "fusion_banner") {
							this.swiperList = item.data.items
						} else if (item.module_key == 'fusion_custom_image') {
							this.fusion_custom_image.push(item)
						}
					})
				}).catch(e => {
					console.log('错误了:', e)
				})
			}
		},
		onLoad() {
			this.getVenueBatchList(1)
			this.getVenueBatchList(2)
			this.getVenuePageList()
		}
	}
</script>

<style lang="scss">

</style>