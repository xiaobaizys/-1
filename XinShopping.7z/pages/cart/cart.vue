<template>
	
</template>

<script>
	export default {
		data() {
			return {
				num: 0
			}
		},
		onShow() {
			this.num++;
			if (this.num % 2 == 0) {
				uni.switchTab({
					url: '/pages/home/home'
				});
			} else {
				uni.navigateTo({
					url: '/pages/cart_page/cart_page'
				})
			}
		},
	}
</script>
