const formatRelativeTime = function(t) {
	var e = new Date(1e3 * t),
		n = new Date,
		a = Date.parse(n) / 1e3,
		i = n.getFullYear(),
		o = (a - t) / 60,
		A = function(t) {
			return (t = (t)) < 10 ? "0" + t : t
		};
		
	return 60 * o <= 60 ? t = (60 * o) + "秒前" : o <= 60 ? t = (o) + "分钟前" : o <= 1440 ? t = Math.trunc(o / 60) +
		"小时前" : o <= 10080 ? t = Math.trunc(o / 60 / 24) + "天前" : i == e.getFullYear() ? t = A(e.getMonth() + 1) +
		"月" + A(e
			.getDate()) + "日 " + A(e.getHours()) + ":" + A(e.getMinutes()) : i > e.getFullYear() && (t = e
			.getFullYear() + "年" + A(e.getMonth() + 1) + "月" + A(e.getDate()) + "日 " + A(e.getHours()) +
			":" + A(e.getMinutes())),
		t
}
export default formatRelativeTime