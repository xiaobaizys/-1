<template>
	<view class="box">
		<template v-if="pic_list.length!==0">
			<view class="images" :class="imgClass">
				<template v-if="pic_list.length!==0">
					<view class="image radius" v-for="(img,imgIndex) in pic_list" :key="imgIndex"
						@click="previewImage(img.img)">
						<image :src="img.img" mode="aspectFill"></image>
					</view>
				</template>
			</view>
		</template>
		<template v-if="video_list.length!==0">
			<view class="mi-video-player user-upload-video">
				<player :src='video_list[0].video_url'></player>
			</view>
		</template>
	</view>
</template>

<script>
	import player from '../../videomuiPlayer/videomuiPlayer.vue'
	export default {
		components: {
			player
		},
		props: {
			pic_list: {
				type: Array,
				default: []
			},
			video_list: {
				type: Array,
				default: () => []
			}
		},
		data() {
			return {
				imgClass: '',
				wrapHeight: ''
			};
		},
		methods: {
			getImgSize(url) {
				return new Promise((resolve, reject) => {
					uni.getImageInfo({
						src: url,
						success: (imgObj) => {
							resolve({
								width: imgObj.width,
								height: imgObj.height
							})
						},
						fail(err) {
							reject('err')
						}
					});
				})
			},
			previewImage(img) {
				let list = []
				list.push(img)
				uni.previewImage({
					current: 0,
					urls: list,
					loop: false,
				})
			},
		},
		async created() {
			let len = this.pic_list.length
			if (len == 1) {
				if (this.pic_list.length !== 0) {
					let imgSize = await this.getImgSize(this.pic_list[0].img)
					let w = imgSize.width
					let h = imgSize.height
					let name = ''
					let l = w / h
					l > 1 ? name = "horizontal" : 1 == l ? name = "square" : l < 1 && (name =
						"vertical")
					this.imgClass = name
				}
			}
			if (len == 2) {
				this.imgClass = 'showTwo'
			}
			if (len == 4) {
				this.imgClass = 'sequence'
			}
			if (len >= 6) {
				this.imgClass = 'sequence'
			}
		},
	}
</script>

<style scoped lang="scss">
	.images.horizontal .image,
	.images.square .image,
	.images.vertical .image {
		width: 100% !important;
		height: 100% !important;
	}

	.radius {
		border-radius: 0.14rem;
	}

	.images {
		margin-top: 0.2rem;
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		border-radius: .14rem;
		height: 2.21rem;
		overflow: hidden;
		position: relative;



		.image {
			width: 33%;
			height: 2.21rem;
			overflow: hidden;

			image {
				width: 100%;
				height: 100%;
			}

		}


	}

	.square {
		width: 4.44rem;
		height: 4.44rem;
	}

	.sequence {
		display: block;
		width: 100%;
		height: auto;
		overflow: hidden;

		.image {
			float: left;
			margin-right: .3%;
			margin-bottom: .02rem;
		}
	}

	.vertical {
		width: 3.33rem;
		height: 4.44rem !important;

		.image {
			width: 100% !important;
			height: 100% !important;
		}
	}

	.horizontal {
		width: 6.624000000000001rem;
		height: 3.726rem !important;

		.image {
			width: 100% !important;
			height: 100% !important
		}
	}

	.showFour {
		width: 4.42rem;
		height: 4.42rem !important;

		.image {
			width: 49.6% !important;
			height: 49.4% !important;
		}
	}

	.showTwo {
		width: 100%;
		height: 3.33rem !important;

		.image {
			width: 49.6% !important;
			height: 3.33rem
		}
	}

	.showSix {
		height: 4.42rem !important;
	}

	.showSix .image:nth-child(-n+3) {
		margin-bottom: .02rem;
	}

	.mi-video-player {
		margin: 0.21rem auto;
		border-radius: 0.1rem;
		overflow: hidden;
		position: relative;
		width: 100%;
		background: #000;
		z-index: 0;
		height: 100%;
	}
</style>