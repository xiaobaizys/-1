<template>
	<view class="mfbs-main-content" style="background-color: rgb(243, 239, 255);">
		<toTop :scrollTop='scrollTop' @toTop='toTop'></toTop>
		<template v-if="title==''||result_list&&result_list.length==0">
			<view class="load">
				<u-loading-page :loading="true"></u-loading-page>
			</view>
		</template>
		<template v-else>
			<mfbsHead :backColor='backColor' :title='title' :isShow='isShow' :img_url='img_url'></mfbsHead>
			<view class="app-content" v-if="result_list.length!=0">
				<view class="app-content-header">
					<block v-for="(item,index) in list" :key="index">
						<view class="head-item">
							<image :src="item.data._hotspot.image" mode="widthFix"></image>
						</view>
						<template v-if="index!=0">
							<twoRow :list="result_list[index-1].list" backColor='rgb(243, 239, 255)'></twoRow>
						</template>
					</block>
				</view>
			</view>

		</template>
	</view>
</template>


<script>
	import mfbsHead from '../../components/mfbs-header/mfbs-header.vue'
	import toTop from '../../components/getTop/getTop.vue'
	import twoRow from '../../components/two-row-detail/two-row-detail.vue'
	let queryData = {
		"query_list": [{
			"resolver": "mishop-grating",
			"sign": "3e9682d14dfbc996fa0f18324fdeade4",
			"parameter": "{\"plan_ids\":[1009273],\"manual_sort\":\"artificial_weight\",\"selectImg\":\"img800s\",\"labels_filter\":\"\",\"need_all\":false,\"limit\":8,\"column_number\":2}",
			"variable": {}
		}, {
			"resolver": "mishop-grating",
			"sign": "69087ec9c006aa11bac4e1504c368339",
			"parameter": "{\"plan_ids\":[1006120],\"manual_sort\":\"artificial_weight\",\"selectImg\":\"img800s\",\"labels_filter\":\"\",\"need_all\":false,\"limit\":20,\"column_number\":2}",
			"variable": {}
		}, {
			"resolver": "mishop-grating",
			"sign": "e96ee1b3bd2b56eddef7fe836a94c1ae",
			"parameter": "{\"plan_ids\":[1006132],\"manual_sort\":\"artificial_weight\",\"selectImg\":\"img800s\",\"labels_filter\":\"\",\"need_all\":false,\"limit\":16,\"column_number\":2}",
			"variable": {}
		}]
	}
	export default {
		components: {
			mfbsHead,
			toTop,
			twoRow,
		},
		onPageScroll(res) {
			this.scrollTop = res.scrollTop
			if (res.scrollTop >= 100) {
				this.isShow = true
				this.img_url = 'left_b'
				this.backColor = 'rgb(244, 244, 244)'
			} else {
				this.backColor = 'transparent'
				this.img_url = 'left'
				this.isShow = false
			}
		},
		data() {
			return {
				img_url: 'left',
				isShow: false,
				scrollTop: 0,
				backColor: 'transparent',
				title: '',
				result_list: [],
				list: []
			};
		},
		methods: {
			toTop() {
				uni.pageScrollTo({
					duration: 0,
					scrollTop: 0,
				})
			},
			getVenuePageList() {
				this.$request.get('/getVenuePageList', {
					page_id: '11859',
					sign: '353bc7d6a68760a8d65da60dd306181d'
				}).then((res) => {
					this.floorList = res.data.data.floors
					this.title = res.data.data.title
					let list = []
					this.floorList.forEach(item => {
						if (item.module_key == "fusion_img_link_map") {
							list.push(item)
						}
					})
					this.list = list
				}).catch(e => {
					console.log('错误了:', e)
				})
			},
			getVenueBatchList() {
				this.$request.get('/getVenueBatchList', {
					page_id: '11859',
					queryData: queryData,
					sign: '353bc7d6a68760a8d65da60dd306181d'
				}).then((res) => {
					this.result_list = res.data.data.result_list
				}).catch(e => {
					console.log('错误了:', e)
				})
			},
		},
		onLoad() {
			this.getVenuePageList()
			this.getVenueBatchList()
		}
	}
</script>

<style lang="scss" scoped>
	.mfbs-main-content {
		view {
			line-height: 1.15;
			font: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
		}

		.head-item {
			image {
				width: 100%;
			}
		}
	}
</style>