import JSEncrypt from 'jsencrypt/bin/jsencrypt.min'
const publicKey ='-----BEGIN PUBLIC KEY-----MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAL9i5UtkRlqVICVdNn1r5E8ll+UFFST4CvMuEqLr4q5ZZYRsnRoW6yK3Z6Nulz9aJEFRMYQ6nAiJjs8xoGGduYcCAwEAAQ==-----END PUBLIC KEY-----'
	
// 加密
export function encrypt(txt) {
	const encryptor = new JSEncrypt()
	encryptor.setPublicKey(publicKey) // 设置公钥
	return encryptor.encrypt(txt) // 对数据进行加密
}

// 解密
export function decrypt(txt, privateKey) {
	const encryptor = new JSEncrypt()
	encryptor.setPrivateKey(privateKey) // 设置私钥
	return encryptor.decrypt(txt) // 对数据进行解密
}