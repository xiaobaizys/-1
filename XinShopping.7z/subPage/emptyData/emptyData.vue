<template>
	<view class="empty">
		<view class="empty-body">
			<u-empty mode="search" icon="../../static/images/empty.png">
			</u-empty>
			<view style="margin-top: .2rem;">
				<u-button text="去首页" shape='circle' type='warning' plain @click='toHome'></u-button>
			</view>
		</view>
	</view>
</template>
<script>
	export default {
		methods: {
			toHome() {
				uni.switchTab({
					url: `/pages/home/home`,
				});
			}
		},
	}
</script>

<style lang="scss" scoped>
	.empty {
		height: 100vh;
		position: relative;
		width: 100%;

		.empty-body {
			position: absolute;
			max-width: 7.2rem;
			margin: 0 auto;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
		}

	}
</style>