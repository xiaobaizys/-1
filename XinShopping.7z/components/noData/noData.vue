<template>
	<view class="no-data-list">
		<view class="img-box">
			<image src="../../static/images/no-q.png" mode=""></image>
		</view>
		<view class="text">
			暂时还没有内容哦～
		</view>
	</view>
</template>

<script>
	export default {
		name: "noData",
		data() {
			return {

			};
		}
	}
</script>

<style lang="scss" scoped>
	.no-data-list {
		padding-top: 0.5rem;
		background: #f6f6f6;
		margin: 0 -0.24rem -0.24rem;
		min-height: 60vh;

		.img-box {
			width: 3.2rem;
			height: 3.2rem;
			margin: 0 auto;

			image {
				width: 3.2rem;
				height: 3.2rem;
			}
		}

		.text {
			text-align: center;
			font-size: .28rem;
			color: rgba(0, 0, 0, .5);
			line-height: .28rem;
		}
	}
</style>