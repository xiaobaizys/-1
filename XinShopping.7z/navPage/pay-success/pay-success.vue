<template>
	<view>
		<view class="header-comp">
			<view class="header">
				<view class="header-bar">
					<view class="fill-height el-flex">
						<view class="header-btn2" @click="toCart">
							<image src="../../static/images/left_b.png" mode=""></image>
						</view>
						<view class="placeholder text-ellipsis">
							支付
						</view>
						<view class="app-header-right">

						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="page-view">
			<view class="page-view-content">
				<view class="inner">
					<view class="icon el-flex">
						<image src="../../static/images/succe.png" mode=""></image>
						<text>支付成功</text>
					</view>
					<view class="p el-flex">
						<text class="l">商户名称</text>
						<text>小米科技有限责任公司</text>
					</view>
					<view class="p el-flex">
						<text class="l">订单金额</text>
						<text>{{total_amount}}元</text>
					</view>
				</view>
			</view>
			<view class="btn" @click="toCart">
				返回商户页面
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				total_amount: 0,
			};
		},
		methods: {
			toCart() {
				uni.redirectTo({
					url: '/subPage/orderList/orderList'
				})
			},
			getOrderData(order_id) {
				let self = this
				let userToken = uni.getStorageSync('USER_TOKEN')
				uni.request({
					url: 'http://42.193.218.104:7744/getOrderData',
					method: 'POST',
					data: {
						order_id: order_id,
					},
					header: {
						Authorization: userToken
					},
					success: function(res) {
						if (res.data.code == 200) {
							self.checkout_goods = res.data.data.goods
							self.addBuyGoodData(res.data.data)
						} else if (res.data.code == 401) {} else if (res.data.code == 403) {

						}
					},
					fail: function(err) {
						uni.redirectTo({
							url: '/pages/error/error'
						})
					}
				})
			},
			addBuyGoodData(good) {
				let self = this
				let userToken = uni.getStorageSync('USER_TOKEN')
				uni.request({
					url: 'http://42.193.218.104:7744/addBuyGoodData',
					method: 'POST',
					header: {
						Authorization: userToken
					},
					data: {
						good: good
					},
					success: function(res) {
						if (res.data.code == 200) {
							self.clearSubPayData([good.order_id])
						} else if (res.data.code == 401) {

						}
					},
					fail: function(err) {

					}
				})
			},
			clearSubPayData(order_id) {
				let self = this
				let userToken = uni.getStorageSync('USER_TOKEN')
				uni.request({
					url: 'http://42.193.218.104:7744/clearSubPayData',
					method: 'POST',
					header: {
						Authorization: userToken
					},
					data: {
						order_id: order_id
					},
					success: function(res) {
						if (res.data.code == 200) {

						} else if (res.data.code == 401) {

						}
					},
					fail: function(err) {

					}
				})
			},
		},
		onLoad(options) {
			this.total_amount = options.total_amount
			this.getOrderData(options.out_trade_no)
		}
	}
</script>

<style lang="scss" scoped>
	view {
		line-height: 1.15;
		box-sizing: border-box;
	}

	.header {
		height: .96rem;
		background: #fff;

		.header-bar {
			background: #fff;
			height: 100%;
		}

		.fill-height {
			height: 100%;

			.header-btn2 {
				display: block;
				width: 0.6rem;
				margin: 0 0.2rem;

				image {
					width: 0.5rem;
					height: 0.5rem;
				}
			}

			.app-header-right {
				min-width: 1rem;
				padding: 0 0.2rem;

				image {
					display: block;
					width: 0.6rem;
					height: 0.6rem;
				}
			}

			.placeholder {
				flex: 1;
				text-align: center;
				font-size: .3rem;
				min-width: 0;
				width: 100%;
				color: rgb(102, 102, 102);
			}
		}
	}

	.page-view {
		position: relative;
		background-color: #f4f8f9;
		height: 100vh;
		padding: .288rem;

		.page-view-content {
			padding-top: .96rem;

			.inner {
				background-color: #fff;
				padding-bottom: .58rem;
			}

			.icon {
				flex-direction: column;
				background-color: #fff;
				padding: .384rem;

				image {
					padding: .384rem;
					width: .96rem;
					height: .96rem;
				}

				text {
					font-size: .384rem;
					font-weight: 800;
				}
			}

			.p {
				padding: .096rem .58rem;
				justify-content: space-between;

				text {
					color: #000;
				}

				.l {
					color: #9898a1;
				}
			}
		}

		.btn {
			margin: 0 auto;
			margin-top: 2.88rem;
			color: #2686c9;
			width: 90%;
			font-size: .301rem;
			text-align: center;
			padding: .288rem;
			border: .0288rem solid #2686c9;
		}
	}
</style>