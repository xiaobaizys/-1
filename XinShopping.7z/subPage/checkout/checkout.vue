<template>
	<view>
		<view class="header-comp">
			<view class="header">
				<view class="header-bar">
					<view class="fill-height el-flex">
						<view class="header-btn2" @click="Back()">
							<image src="../../static/images/left_b.png" mode=""></image>
						</view>
						<view class="placeholder text-ellipsis">
							用户结算
						</view>
						<view class="app-header-right"></view>
					</view>
				</view>
			</view>
		</view>
		<view class="checkout" v-if="isShow">
			<view class="page-wrap">
				<template v-if="checkout_goods.length===0">
					<view class="error-page el-flex">
						<view class="error-icon">
							<image src="../../static/images/star.8c780b0566.png" mode="widthFix"></image>
						</view>
						<view class="error-text">
							您的购物车为空，请先去选购几件心仪的商品吧
						</view>
					</view>
				</template>
				<template v-else>
					<view class="b1 more" @click="toAddress">
						<template v-if="Object.keys(addressData).length==0">
							<view class="b14">
								添加收货地址
							</view>
						</template>
						<template v-else>
							<view class="checkout_address">
								<view class="b11">
									<view class="p">
										<text>
											{{addressData.consignee}}
										</text>
										<text>
											{{addressData.tel|phone}}
										</text>
									</view>
								</view>
								<view class="b13">
									<view class="p">
										{{addressData|city}}
									</view>
								</view>
							</view>

						</template>
					</view>
					<view class="ui-line"></view>
					<view class="b8">
						<block v-for="(item,index) in checkout_goods" :key="index">
							<view class="b8w">
								<view class="b81">
									<image :src="item.img_url" mode="widthFix"></image>
								</view>
								<view class="b82">
									<view class="name">
										<view class="p">
											<text>{{item.name}}</text>
										</view>
									</view>
								</view>
								<view class="b83">
									<view class="item-price">
										<view class="s">
											<text class="count" v-if="item.count!=1">{{item.count}} x </text>
											<text class="pri">{{`${Number(item.price).toFixed(2)}`}}</text>
										</view>
									</view>
								</view>
							</view>
							<block v-for="(pack,packIndex) in item.packageList" :key="`${index}_${packIndex}`">
								<view class="b8w">
									<view class="b81">
										<image :src="pack.img_url" mode="widthFix"></image>
									</view>
									<view class="b82">
										<view class="name">
											<view class="p">
												<text>{{pack.name}}</text>
											</view>
										</view>
									</view>
									<view class="b83">
										<view class="item-price">
											<view class="s">
												<text class="count" v-if="pack.count!=1">{{pack.count}} x </text>
												<text class="pri">{{`${Number(pack.price).toFixed(2)}`}}</text>
											</view>
										</view>
									</view>
								</view>
							</block>
							<block v-for="(serve,serveIndex) in item.serveArr" :key="`${index}_${serveIndex}_0`">
								<view class="b8w">
									<view class="b81">
										<template v-if="serve.service_type_name=='service_micloud'">
											<image
												src="https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1572490983.06999803.jpg"
												mode="widthFix"></image>
										</template>
										<template v-else-if="serve.service_type_name=='service_prolong'">
											<image
												src="https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202205231453_2126ed0b86f8fac1a0498a053cf5c337.png"
												mode="widthFix"></image>
										</template>
										<template v-else>
											<image
												src="https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202212261525_bfb3fcf0720b57a3f90cde2a2d58d98e.png"
												mode="widthFix"></image>
										</template>
									</view>
									<view class="b82">
										<view class="name">
											<view class="p">
												<text>{{serve.name}}</text>
											</view>
										</view>
									</view>
									<view class="b83">
										<view class="item-price">
											<view class="s">
												<text class="count" v-if="serve.count!=1">{{serve.count}} x </text>
												<text class="pri">{{`${Number(serve.price).toFixed(2)}`}}</text>
											</view>
										</view>
									</view>
								</view>
							</block>
						</block>
					</view>
					<view class="ui-line"></view>
					<view class="b3">
						<view class="dl">
							<view class="dt">
								<view class="str">
									运费
								</view>
								<view class="vi">
									<text>包邮</text>
								</view>
							</view>
						</view>
					</view>
					<view class="gap-line"></view>
					<view class="b3">
						<view class="dl">
							<view class="dt">
								<view class="str">
									电子普通发票
								</view>
								<view class="vi el-flex">
									<text>个人</text>
									<view class="image-icons icon-arrow-down">
										<image src="../../static/images/icon_back.png" mode=""></image>
									</view>
								</view>
							</view>
						</view>
					</view>
					<view class="gap-line"></view>
					<view class="b3">
						<view class="dl">
							<view class="dt">
								<view class="str">
									优惠券
								</view>
								<view class="vi el-flex">
									<text class="recommend-text">选择推荐优惠</text>
									<text>无可用</text>
									<view class="image-icons icon-arrow-down">
										<image src="../../static/images/icon_back.png" mode=""></image>
									</view>
								</view>
							</view>
						</view>
					</view>
					<view class="ui-line"></view>
					<view class="b5">
						<view class="p5">
							<text class="str">
								商品价格：
							</text>
							<text>{{checkout_goods|AllSelectMoney}}</text>
						</view>
						<view class="p5">
							<text class="str">
								配送费用：
							</text>
							<text>0.00</text>
						</view>
					</view>
					<view class="ui-line"></view>
					<view class="b7">
						<view class="info-tips text-ellipsis" v-if="Object.keys(addressData).length!==0">
							配送至：{{addressData|city}}
						</view>
						<view class="ui-flex el-flex">
							<view class="b71 ">
								<text class="text">共{{checkout_goods|AllSelectTotal}}件 合计: </text>
								<text class="str">{{checkout_goods|AllSelectMoney}}</text>
							</view>
							<view class="b72" @click="toPayView">
								<view class="ui-button">
									去付款
								</view>
							</view>
						</view>
					</view>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	import showModal from '../../common/js/showModal.js'
	export default {
		data() {
			return {
				addressData: {},
				checkout_goods: [],
				isShow: false
			};
		},
		filters: {
			phone: function(tel) {
				if (tel) {
					let str = tel.replace(/^(\d{3})\d*(\d{4})$/, '$1****$2');
					return str
				}
			},
			AllSelectTotal: function(checkout_goods) {
				let total = 0
				checkout_goods.forEach(i => {
					total += i.count
					total += i.packageList && i.packageList.length
					total += i.serveArr && i.serveArr.length
				})
				return total;
			},
			AllSelectMoney: function(checkout_goods) {
				let total = 0
				checkout_goods.forEach(i => {
					total += Number(i.price) * i.count
					i.packageList && i.packageList.forEach(j => {
						total += Number(j.price)
					})
					i.serveArr && i.serveArr.forEach(j => {
						total += Number(j.price)
					})
				})
				return `${total.toFixed(2)}`;
			},
			city: function(obj) {
				if (obj.address) {
					return obj.province + ' ' + obj.city + ' ' + obj.district + ' ' +
						obj.area + ' ' + obj.address;
				}
			},
		},
		methods: {
			Back() {
				uni.navigateBack(-1)
			},
			getPayData() {
				let self = this
				let userToken = uni.getStorageSync('USER_TOKEN')
				uni.request({
					url: 'http://42.193.218.104:7744/getPayData',
					method: 'GET',
					header: {
						Authorization: userToken
					},
					success: function(res) {
						if (res.data.code == 200) {
							self.checkout_goods = res.data.data
							self.isShow = true
						} else if (res.data.code == 401) {
							self.isShow = false
							showModal()
						}
					},
					fail: function(err) {
					}
				})
			},
			clearPayData(order_id) {
				let userToken = uni.getStorageSync('USER_TOKEN')
				uni.request({
					url: 'http://42.193.218.104:7744/clearPayData',
					method: 'POST',
					header: {
						Authorization: userToken
					},
					success: function(res) {
						if (res.data.code == 200) {
							uni.navigateTo({
								url: `/subPage/pay-view/pay-view?order_id=${order_id}`
							})
						} else if (res.data.code == 401) {
							self.isShow = false
							showModal()
						}
					},
					fail: function(err) {

					}
				})
			},
			deleteCartData(goods_id, callback) {
				let userToken = uni.getStorageSync('USER_TOKEN')
				uni.request({
					url: 'http://42.193.218.104:7744/deleteCartData',
					method: 'POST',
					data: {
						goods_id: goods_id
					},
					header: {
						Authorization: userToken
					},
					success: function(res) {
						if (res.data.code == 200) {
							callback(true)
						} else {
							callback(false)
						}
					},
					fail: function(err) {
						callback(false)
					}
				})
			},
			addSubPayData(items) {
				let self = this
				let userToken = uni.getStorageSync('USER_TOKEN')
				uni.request({
					url: 'http://42.193.218.104:7744/addSubPayData',
					method: 'POST',
					data: {
						items: items,
					},
					header: {
						Authorization: userToken
					},
					success: function(res) {
						if (res.data.code == 200) {
							let list = []
							items.forEach(i => {
								list.push(i.goods_id)
							})
							self.deleteCartData(list, r => {
								if (r) {
									self.clearPayData(res.data.data.order_id)
								} else {
									uni.showToast({
										title: '未登录或参数无效',
										icon: 'error'
									})
								}
							})

						} else if (res.data.code == 401) {
							self.isShow = false
							showModal()
						}
					},
					fail: function(err) {

					}
				})
			},
			toPayView() {
				if (!this.addressData || Object.keys(this.addressData).length === 0) {
					uni.showModal({
						title: '温馨提示',
						showCancel: false,
						content: '请添加收货地址',
						success(res) {
							if (res.confirm) {
								return;
							}
						}
					})
				} else {
					this.addSubPayData(this.checkout_goods)
				}
			},
			toAddress() {
				if (Object.keys(this.addressData).length == 0) {
					uni.navigateTo({
						url: '/subPage/addressEdit/addressEdit'
					})
				} else {
					uni.navigateTo({
						url: '/subPage/addressList/addressList'
					})
				}
			}
		},
		onUnload() {
			uni.$off('come_from_pay')
		},
		onLoad() {
			// #ifdef H5
			let isLogin = uni.getStorageSync('isLogin')
			if (!isLogin || isLogin == 'no') {
				showModal()
			}
			// #endif
			this.getPayData()
		},
		onShow() {
			uni.$on('come_from_pay', res => {
				if (res) {
					uni.redirectTo({
						url: '/subPage/orderList/orderList'
					})
				}
			})
			let address_item = uni.getStorageSync('checkout_address')
			if (!address_item || address_item.length === 0) {
				return;
			} else {
				address_item.forEach(item => {
					if (item.is_default) {
						this.addressData = item
					}
				})
			}
			uni.$on('addSuccess', () => {
				let address_item = uni.getStorageSync('checkout_address')
				if (!address_item || address_item.length === 0) {
					return;
				} else {
					address_item.forEach(item => {
						if (item.is_default) {
							this.addressData = item
						}
					})
				}
			})
		},
	}
</script>

<style lang="scss" scoped>
	view {
		line-height: 1.15;
		box-sizing: border-box;
	}

	.header {
		height: .96rem;
		background-color: rgb(242, 242, 242);


		.header-bar {
			height: 100%;
		}

		.fill-height {
			height: 100%;

			.header-btn2 {
				display: block;
				width: 0.6rem;
				margin: 0 0.2rem;

				image {
					width: 0.5rem;
					height: 0.5rem;
				}
			}

			.app-header-right {
				min-width: 1rem;
			}

			.placeholder {
				flex: 1;
				text-align: center;
				font-size: .3rem;
				min-width: 0;
				width: 100%;
				color: rgb(102, 102, 102);
			}
		}
	}

	.checkout {
		padding-top: .96rem;
		padding-bottom: 1.55rem;
		text-align: left;
		font-size: .24rem;
		background: #f5f5f5 !important;
		min-height: 100vh;

		.more:after {
			content: "";
			position: absolute;
			right: 0.32rem;
			top: 50%;
			width: 0.2rem;
			height: 0.2rem;
			border-left: 1px solid currentColor;
			border-top: 1px solid currentColor;
			transform: translate3d(0, -50%, 0) rotate(135deg);
			-webkit-transform: translate3d(0, -50%, 0) rotate(135deg);
		}

		.b1,
		.b4,
		.b5,
		.b6 {
			padding: 0.26rem 0.4rem;
			background: #fff;
		}

		.page-wrap {
			height: 100%;
			overflow-x: hidden;
			overflow-y: auto;

			.error-page {
				flex-direction: column;

				.error-icon {
					margin-top: 1rem;
					width: 2.5rem;

					image {
						width: 100%;
					}
				}

				.error-text {
					margin-top: 0.2rem;
					color: #676767;
					line-height: 1.5em;
				}
			}

			.ui-line {
				border-top: 1px solid #e0e0e0;
				border-bottom: 1px solid #e0e0e0;
				height: 0.2rem;
				background: #f5f5f5;
				overflow: hidden;
				clear: both;
			}

			.b1 {
				background: #fff url(../../static/images/bd1.png) 0 0 repeat-x;
				background-size: 0.52rem 0.08rem;
				padding-top: 0.4rem;
				padding-bottom: 0.3rem;
				position: relative;

				.b14 {
					font-size: .26rem;
					font-weight: 700;
				}

				.checkout_address {
					.b11 {
						font-size: .3rem;
						font-weight: 700;
						margin-bottom: 0.2rem;

						.p {
							text {
								font-size: .3rem;
								font-weight: 700;
								margin-right: 0.1rem;
							}
						}
					}

					.b13 {
						line-height: .28rem;
						color: #757575;
						margin-right: 0.3rem;

						.p {
							font-size: .24rem;
							line-height: .28rem;
							color: #757575;
						}
					}
				}
			}

			.b8 {
				background: #fff;

				.b8w {
					display: flex;
					flex-direction: row;
					align-items: center;
					line-height: .3rem;
					margin: 0 0.4rem;
					padding: 0.14rem 0;
					border-bottom: 1px solid #eee;

					.b81 {
						margin-right: 0.2rem;
						width: 0.8rem;
						height: 0.8rem;

						image {
							width: 0.8rem;
						}
					}

					.b82 {
						flex: 1;

						.name {
							.p {
								text {
									margin-right: 0.1rem;
									font-size: .24rem;
								}
							}
						}
					}

					.b83 {
						text-align: right;

						.item-price {
							.s {
								font-weight: bolder;

								.count {
									font-weight: normal;
									font-size: .24rem;
									color: #3c3c3c;
									margin-right: .1rem;
									line-height: .3rem;
								}

								.pri {
									font-size: .24rem;
								}
							}
						}
					}
				}
			}

			.gap-line {
				background: #eee;
				height: 1px;
				padding-bottom: 0;
				margin: 0px 0.4rem;
			}

			.str {
				color: #3c3c3c;
				font-weight: bolder;
				font-size: .24rem;
			}

			.b3 {
				background: #fff;

				.dl {
					.dt {
						display: flex;
						align-items: center;
						justify-content: space-between;
						padding: 0.26rem 0.4rem;



						.vi {
							text {
								color: #bdbdbd;
							}

							.recommend-text {
								font-size: 10px;
								color: #f60;
								padding: 2px 2px 1px;
								border: 1px solid #f60;
								border-radius: 2px;
								margin-right: 18px;
								transform: scale(.8);
							}

							.image-icons {
								width: 0.4rem;
								height: 0.4rem;
								display: inline-block;

								image {
									width: 0.4rem;
									height: 0.4rem;
									display: inline-block;
								}
							}
						}
					}
				}
			}

			.b5 {
				background: #fff;

				.p5 {
					line-height: 2em;

					text {
						font-size: .24rem;
					}

					.str {}
				}
			}

			.b7 {
				transform: none;
				position: fixed;
				bottom: 0;
				left: 0;
				right: 0;
				background: #fff;
				border-top: 1px solid #e0e0e0;
				z-index: 10;
				max-width: 7.2rem;
				margin: 0 auto;

				.info-tips {
					background: #fbf3c4;
					color: #b57842;
					opacity: .7;
					font-size: .24rem;
					padding: 0.12rem 0.2rem;
					line-height: .3rem;
				}

				.ui-flex {
					align-items: center;

					.b71 {
						font-size: .3rem;
						color: #ff4d14;
						width: 100%;
						text-align: center;

						.text {
							margin-right: .1rem;
						}

						.str {
							font-size: .3rem;
							color: #ff4d14;
							text-align: center;
						}
					}

					.b72 {
						width: 100%;

						.ui-button {
							display: block;
							background-color: #ff5722;
							text-align: center;
							height: 1rem;
							line-height: 1rem;
							border: 1px solid #ff5722;
							font-size: .3rem;
							color: #fff;
						}
					}
				}
			}
		}
	}
</style>