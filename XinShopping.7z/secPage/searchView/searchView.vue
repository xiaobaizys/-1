<template>
	<view >
		<view class="header">
			<view class="fill-height el-flex">
				<view class="header-btn2">
					<image src="../../static/images/left_b.png" mode="widthFix" @click="Back()"></image>
				</view>
				<view class="placeholder">
					<input type="text" placeholder="搜索商品名称" v-model="keyword" @blur="blur" @focus="focus">
					<view class="close" v-if="keyword!==''" @click="keyword=''">
						<image src="../../static/images/close.png" mode=""></image>
					</view>
				</view>
				<view class="share-btn">
					<view class="app-header-item">
						<view class="ipt-img-box el-flex">
							<image src="../../static/images/search_b.png" mode="widthFix"
							@click="getSearchItem({title:keyword})"
								></image>
						</view>
					</view>
				</view>
			</view>
			<template v-if="searchList.length!==0&&isShowList">
				<view class="search-key-list">
					<block v-for="(item,index) in searchList" :key="index">
						<view class="li" @click="getSearchItem({title:item.title})">
							<view class="li-item">
								<text>{{item.title}}</text>
							</view>
						</view>
					</block>
				</view>
			</template>
		</view>
		<view class="content">
			<u-modal :show="isShow" @confirm="confirm" ref="uModal" :asyncClose="true" title='是否删除全部搜索历史？'
				:showCancelButton='true' @cancel='isShow=false'>

			</u-modal>
			<template v-if="searchData.length!==0">
				<view class="history">
					<view class="title">
						<text>搜索历史</text>
						<image src="../../static/images/delete.png" mode="" @click="clearAll"></image>
					</view>
					<view class="buttons_out scroll">
						<view class="buttons_in">
							<block v-for="(item,index) in searchData" :key="index">
								<text @click="getSearchItem({title:item.title})">{{item.title}}</text>
							</block>
						</view>
					</view>
				</view>
			</template>
			<view class="tabs">
				<view class="title">
					<text>搜索发现</text>
				</view>
			</view>
			<view class="discovery">
				<block v-for="(item,index) in discover_list" :key="index">
					<view class="item" @click="getSearchItem({title:item.desc})">
						<text>{{item.desc}}</text>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isShow: false,
				keyword: '',
				discover_list: [],
				searchData: [],
				searchList: [],
				isShowList: false
			};
		},
		watch: {
			keyword(newVal) {
				if (newVal == '') return;
				this.getSearchSuggestion(newVal)
			}
		},
		methods: {
			Back() {
				uni.navigateBack(-1)
			},
			focus() {
				this.isShowList = true
			},
			blur() {
				setTimeout(() => {
					this.isShowList = false
				}, 100)
			},
			toSearchItemDetail(key) {
				if (key == '') return;
				uni.navigateTo({
					url: `/secPage/searchItemDetail/searchItemDetail?key=${key}`
				})
			},
			confirm() {
				uni.setStorageSync('searchInfo', []);
				this.searchData = []
				this.isShow = false
			},
			clearAll() {
				this.isShow = true
			},
			getSearchItem(item) {
				if (item.title == '') return;
				let index = this.searchData.findIndex(i => {
					return i.title == item.title
				})
				if (index !== -1) {
					this.searchData.splice(index, 1);
					this.searchData.unshift({title:item.title});
				} else {
					this.searchData.unshift({title:item.title});
				}
				uni.setStorageSync('searchInfo', this.searchData);
				this.toSearchItemDetail(item.title)
			},
			getSearchSuggestion(query) {
				this.$request.get('/getSearchSuggestion', {
					query: query
				}).then((res) => {
					if (res.data.data) {
						this.searchList = res.data.data.list
					} else {
						this.searchList = []
					}

				}).catch(e => {
					console.log('错误了:', e)
				})
			},
			getSearchDefault() {
				this.$request.get('/getSearchDefault').then((res) => {
					this.discover_list = res.data.data.discover_list
				}).catch(e => {
					console.log('错误了:', e)
				})
			}
		},
		onLoad() {
			this.getSearchDefault()
			this.searchData = uni.getStorageSync('searchInfo')
		},
	}
</script>

<style lang="scss" scoped>
	view {
		line-height: 1.15;
	}

	.search-key-list {
		text-align: left;
		position: fixed;
		top: 0.8rem;
		z-index: 10;
		width: 100%;
		height: 100%;
		background: rgba(0, 0, 0, .5);

		.li {
			background: #fff;

			.li-item {
				border-bottom: 1px solid rgba(0, 0, 0, .15);
				margin: 0 0.32rem;
				display: flex;
				height: 0.95rem;

				text {
					display: inline-block;
					width: 100%;
					overflow: hidden;
					height: 0.95rem;
					font-size: .28rem;
					line-height: .95rem;
					white-space: nowrap;
					color: #333;
				}
			}
		}
	}

	.header {
		max-width: 720px !important;
		min-width: 350px !important;
		margin: 0 auto;
		height: 0.8rem;
		background: #f2f2f2;
		position: sticky;
		top: 0;
		left: 0;
		right: 0;
		z-index: 99;
		line-height: 1.15;

		view {
			line-height: 1.15;
		}

		.fill-height {
			height: 100%;
			display: flex;
			align-items: center;
			flex: 1 1 auto;
			flex-wrap: nowrap;

			.header-btn2 {
				display: block;
				margin: 0 0.2rem;
				color: #666;
				margin-top: .03rem;

				image {
					width: 0.5rem;
					height: 0.5rem;
				}
			}

			.share-btn {
				display: flex;
				align-items: center;

				.app-header-item {
					display: block;
					width: 0.6rem;
					margin: 0 0.2rem;

					.ipt-img-box {
						width: 0.6rem;
						height: 0.6rem;

						image {
							display: block;
							width: 0.6rem;
							height: 0.6rem;
						}
					}
				}

			}

			.placeholder {
				flex: 1;
				font-size: .3rem;
				position: relative;

				input {
					border: 1px solid #e5e5e5;
					border-radius: 0.04rem;
					padding: 0 0.5rem 0 0.2rem;
					outline: 0;
					font-size: .3rem;
					font-weight: 400;
					height: 0.5rem;
					background: white;
					line-height: normal;
				}

				.close {
					position: absolute;
					right: 0.12rem;
					top: 50%;
					transform: translateY(-50%);
					width: 0.27rem;
					height: .27rem;

					image {
						width: 100%;
						height: 100%;

					}
				}
			}
		}
	}

	.content {
		padding: 0.4rem 0.32rem;
		text-align: left;

		.title {
			display: flex;
			align-items: center;
			justify-content: space-between;
			font-size: .28rem;
			font-weight: 700;

			text {
				font-size: .28rem;
				font-weight: 700;
			}

			image {
				width: 0.28rem;
				height: 0.28rem;
			}
		}

		.history {
			margin-bottom: 0.6rem;

			.buttons_out {
				max-height: 1.8rem;
				margin-top: 0.08rem;
				margin-right: -0.24rem;
				overflow: hidden;

				.buttons_in {
					text {
						vertical-align: bottom;
						overflow: hidden;
						white-space: nowrap;
						text-overflow: ellipsis;
						max-width: 5.02rem;
						margin-top: 0.24rem;
						margin-right: 0.24rem;
						display: inline-block;
						padding: 0.15rem 0.24rem;
						background: rgba(0, 0, 0, .04);
						font-size: .24rem;
						border-radius: 0.54rem;
					}
				}
			}


		}

		.tabs {
			font-size: .28rem;
			line-height: .28rem;
			font-weight: 700;
			margin-bottom: 0.32rem;
		}

		.discovery {
			padding-left: 0.24rem;

			.item {
				display: inline-flex;
				align-items: center;
				width: 50%;
				margin-bottom: 0.35rem;
				font-size: .24rem;

				text {
					display: inline-block;
					max-width: 2.34rem;
					overflow: hidden;
					text-overflow: ellipsis;
				}
			}
		}
	}
</style>