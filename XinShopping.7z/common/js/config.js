// 配置信息
export default {
	// api请求前缀
	webUrl: 'http://42.193.218.104:6455',
	// // #ifdef H5
	// webUrl: 'http://localhost:8082/api/v1',
	// // #endif
	// websocket地址
	websocketUrl: "wss://api.yuchentt.com/wss",
	// 消息提示tabbar索引
	TabbarIndex: 2
}