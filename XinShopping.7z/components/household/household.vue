<template>
	<view>
		<view class="house-img house-img_1" v-if="otherList[0]">
			<image :src="`https:${otherList[0].body.items[0].img_url}`" mode="widthFix" lazy-load></image>
		</view>
		<view class="divider_line"></view>
		<view class="house-img house-img_2" v-if="otherList[1]">
			<image :src="`https:${otherList[1].body.items[0].img_url}`" mode="widthFix" lazy-load></image>
		</view>
		<view class="divider_line"></view>
		<view class="house-item">
			<u-row v-if="shopList[0]" :gutter='8'>
				<u-col span="4" v-for="(item,index) in shopList[0].body.items" :key="index" @click='toShopDetail(item)'>
					<view class="box-item">
						<view class="item-img">
							<image :src="item.img_url" mode="heightFix" lazy-load></image>
						</view>
						<view class="info-box">
							<text class="name text-ellipsis">{{item.product_name}}</text>
							<text class="info text-ellipsis">{{item.product_brief}}</text>
							<text class="moneys">¥{{item.show_price}}</text>
						</view>
					</view>
				</u-col>
			</u-row>
		</view>
		<view class="divider_line"></view>
		<block v-for="(item,index) in otherList.slice(2)">
			<view class="house-img house-img_4">
				<image :src="`https:${item.body.items[0].img_url}`" mode="widthFix" lazy-load></image>
			</view>
			<view class="divider_line"></view>
		</block>
		<view class="house-item">
			<u-row v-if="shopList[1]" :gutter='8'>
				<u-col span="4" v-for="(item,index) in shopList[1].body.items" :key="index" @click='toShopDetail(item)'>
					<view class="box-item">
						<view class="item-img">
							<image :src="item.img_url" mode="heightFix" lazy-load></image>
						</view>
						<view class="info-box">
							<text class="name text-ellipsis">{{item.product_name}}</text>
							<text class="info text-ellipsis">{{item.product_brief}}</text>
							<text class="moneys">¥{{item.show_price}}</text>
						</view>
					</view>
				</u-col>
			</u-row>
		</view>
		<view class="divider_line"></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				shopList: [],
				otherList: [],
			};
		},
		methods: {
			toShopDetail(item) {
				let action = item.action
				if (action.productId && action.type == "product") {
					uni.navigateTo({
						url: `/subPage/proddetail/proddetail?id=${action.productId}`,
						success() {
			
						}
					})
				} else if (action.path && action.type == "product") {
					uni.navigateTo({
						url: `/subPage/proddetail/proddetail?id=${action.path}`,
						success() {
			
						}
					})
				}
			
			},
			fetchData() {
				this.$request.get('/getData', {
					type: 'activity',
					page_id: '18642'
				}).then((res) => {
					let shopList = []
					let otherList = []
					let data = res.data.data.data.sections
					data.forEach(item => {
						if (item.view_type == 'list_three_type4') {
							shopList.push(item)
						} else if (item.view_type == 'cells_auto_fill') {
							otherList.push(item)
						}
					})
					this.otherList = otherList
					this.shopList = shopList
				}).catch(e => {
					console.log('错误了:', e)
				})
			},
		},
		mounted() {
			this.fetchData()
		}
	}
</script>

<style lang="scss" scoped>
	.house-img {
		width: 100%;

		image {
			width: 100%;
		}
	}

	.house-img_1 {
		height: 128rpx;
	}

	.house-img_2 {
		height: 140rpx;
	}

	.house-img_4 {
		height: 108rpx;
	}

	.info-box {
		line-height: 1.2;
		padding: 0.2rem 0.1rem;
		text-align: center;
		background: #fff;
		padding-bottom: 0.23rem;
		border-bottom-left-radius: 0.1rem;
		border-bottom-right-radius: 0.1rem;

		.name {
			display: inline-block;
			font-size: .24rem;
			font-weight: bolder;
			color: #3c3c3c;
			width: 100%;
		}

		.info {
			display: inline-block;
			color: #3c3c3c;
			font-size: .2rem;
			line-height: 1.6em;
			text-align: center;
			width: 100%;
		}

		.moneys {
			font-weight: 600;
			text-align: center;
			font-family: Heiti SC, STHeiti;
			line-height: 1.2;
			font-size: .28rem;
			color: rgb(245, 75, 75);
		}
	}

	.house-item {
		padding: 0 0.16rem;
		background: rgb(225, 65, 57);

		.box-item {
			overflow: hidden;
			width: 2.21rem;
		}

		.item-img {
			width: 2.21rem;
			height: 2.21rem;

			image {
				width: 2.21rem;
				height: 2.21rem;
				border-top-left-radius: 0.1rem;
				border-top-right-radius: 0.1rem;
			}
		}

	}

	.divider_line {
		border-bottom: 0.16rem solid rgb(225, 65, 57);
		background-color: rgb(225, 65, 57);
	}
</style>